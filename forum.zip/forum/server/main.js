import { Meteor } from 'meteor/meteor';
import { check, Match } from 'meteor/check';

// define collections on server
import '../imports/api/messages.js';
import '../imports/api/profiles.js';
import '../imports/api/users.js';
import '../imports/api/topics.js'; 
import '../imports/api/pm.js';
import {Presences} from '../imports/api/presences.js';

var conections = {};

var expire = function(id) {
  Presences.remove(id);
  delete conections[id];
}

var tick = function(id) {
  conections[id].lastSeen = Date.now();
}

Meteor.startup(() => {
  // code to run on server at startup
  Presences.remove({});
});

Meteor.onConnection(function(connection){
  Presences.insert({_id: connection.id});

  conections[connection.id] = {};
  tick(connection.id);

  connection.onClose(function() {
    expire(connection.id);
  });
});

Meteor.methods({
  presenceTick: function() {
    check(arguments, [Match.Any]);
    if (this.connection && conections[this.connection.id])
      tick(this.connection.id);
  },
  presenceOff: function() {
    Presences.remove({userId: Meteor.userId()});
  }
});

Meteor.setInterval(function() {
  _.each(this.connections, function(connection, id){
      if (connection.lastSeen < (Date.now() - 10000))
        expire(id);
  });
}, 5000);
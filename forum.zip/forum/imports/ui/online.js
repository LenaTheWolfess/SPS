import './online.html';
import { Profiles } from '../api/profiles';

Template.online.onCreated(function(){
    Meteor.subscribe('users');
});
Template.online.helpers({
    getName(){
        if (!this.userId)
            return "guest";
        let name = Meteor.users.findOne({_id: this.userId}).username;
        return name;
    }
});
Template.online.events({
    'click .onlineName'(){
        if(!this.userId)
            return;
        FlowRouter.go('/profile/:id', {id: this.userId});
    },
})
import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import './main-page.js';
import './profile-page.js';
import './navigation.html';
import './body.html';

Template.body.onCreated(function () {
    this.state = new ReactiveDict();
});

Template.body.helpers({
})

Template.body.events({
})
import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import { Topics } from '../api/topics.js';

import './newTopic.js';
import './pms.js';
import './topics.js';
import './online.js';
import './main-page.html';
import { Presences } from '../api/presences.js';

Template.mainPage.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('topics');
    Meteor.subscribe('presences');
});

Template.mainPage.helpers({
    topics() {
        return Topics.find({});
    },
    onlines(){
        return Presences.find({state:"online"});
    }
})

Template.mainPage.events({
    'click .add-topic': function(){
       FlowRouter.go('/newTopic/');
    }
})
import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';

import './topic-page.js';
import './topics.html';

Template.topic.events({
    'click .topicName'(){
        FlowRouter.go('/topic/:id',{id: this._id});
    }
})
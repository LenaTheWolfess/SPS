import { Meteor } from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import { Template } from 'meteor/templating';

import {Messages} from '../api/messages.js';
import {Profiles} from '../api/profiles.js';

import './messages.html';

Template.registerHelper('formateDate', function(date){
    return date.getDate() + "." + date.getMonth() + "." +date.getFullYear() + " at " + date.getHours() + ":"+date.getMinutes();
});

Template.message.created = function() {
    this.state = new ReactiveDict();
};

Template.message.helpers({
    isOwner() {
        return this.owner == Meteor.userId();
    },
    messageEditing() {
        return Template.instance().state.get('messageEditing');
    },
});

Template.message.events({
    'click .delete'() {
        Meteor.call('messages.remove', this._id);
    },
    'click .name'(){
        FlowRouter.go('/profile/:id', {id: this.owner});
    },
    'click .edit'(){
        Template.instance().state.set('messageEditing', true);
    },
    'click .cancel-b'(){
        Template.instance().state.set('messageEditing', false);
    },
    'submit .message-edit-form'(event) {
        event.preventDefault();
        const target = event.target;
        let msg = {_id: this._id, text: target.text.value};
        Meteor.call('messages.update', msg);
        Template.instance().state.set('messageEditing', false);
    }
});
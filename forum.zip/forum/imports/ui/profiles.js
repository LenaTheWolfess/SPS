import { Meteor } from 'meteor/meteor';
import {Template} from 'meteor/templating';
import {ReactiveDict} from 'meteor/reactive-dict';

import {Profiles} from '../api/profiles.js';
import '../api/users.js';

import './pm.js';
import './profiles.html';

Template.profile.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('profiles');
    Meteor.subscribe('users');
});

Template.profile.helpers({
    profile:()=>{
        var id = FlowRouter.getParam('id');
        if (!id) {
            id = Meteor.userId();
        }
        return Profiles.findOne({userId: id});
    },
    isOwner() {
        var id = FlowRouter.getParam('id');
        return !id || id == Meteor.userId();
    },
    EditProfile(){
        const instance = Template.instance();
        return instance.state.get('showEditProfile');
    },
    hasProfile(){
        var id = FlowRouter.getParam('id');
        if (!id) {
            id = Meteor.userId();
        }
        return Profiles.findOne({userId: id}) != null;
    },
    nick(){
        var id = FlowRouter.getParam('id');
        if(!id) {
            id = Meteor.userId();
        }
        var user = Meteor.users.findOne({_id: id});
        if (user == null)
            return "";
        return user.username;
    }
});

Template.profile.events({
    'click .profile-edit-b': function(){
        const instance = Template.instance();
        instance.state.set('showEditProfile', true);
    },
    'click .privateMessage-b':function(){
        var id = FlowRouter.getParam('id');
        if(!id)
           return;
        FlowRouter.go('/PM/:id', {id: id});
    },
    'submit .edit-profile'(event) {
        event.preventDefault();
        const target = event.target;
        
        const fName = target.p_firstName.value;
        const sName = target.p_secondName.value;
        const town = target.p_town.value;
        const country = target.p_country.value;
        const age = target.p_age.value;

        var profile = Profiles.findOne({userId: Meteor.userId()});

        profile.firstName = fName;
        profile.secondName = sName;
        profile.town = town;
        profile.country = country;
        profile.age = age;

        Meteor.call('profiles.update', profile);

        const instance = Template.instance();
        instance.state.set('showEditProfile', false);
    }, 
});
import '../imports/startup/accounts-config.js';
import '../imports/ui/body.js';
import { Presences } from '../imports/api/presences.js';

Presence = {};
Presence.state = function() {
    return 'online';
};

if(Meteor.isClient) {
    // display client connection to the server in console 
    Meteor.autorun(function () {
        var stat = Meteor.status().status;
        if (stat === "connected") {
            console.log("connected");
            return;
        } else if (stat === "connecting") {
            console.log("connecting to: ");
        } else if(stat === "failed") {
          console.log("failed");
          return;
        } else if(stat === "waiting") {
          console.log("waiting");
        } else if(stat === "offline") {
          console.log("offline");
          Meteor.call('presenceOff');
          return;
        }
        else {
          console.log("disconnected");
          Meteor.call('presenceOff');
          return;
        }
    });
}

Meteor.startup(function() {
    Tracker.autorun(function(){
        if(Meteor.status().status == 'connected')
            Meteor.call('updatePresence', Presence.state());
    });

    Meteor.setInterval(function(){
        Meteor.call('presenceTick');
    }, 5000);
});

// for building app
// ip of server
var theURL = '192.168.1.14:3000';
// set
Meteor.absoluteUrl.defaultOptions.rootUrl = theURL;
process.env.ROOT_URL = theURL;
process.env.MOBILE_ROOT_URL = theURL;
process.env.MOBILE_DDP_URL = theURL;
process.env.DDP_DEFAULT_CONNECTION_URL = theURL;
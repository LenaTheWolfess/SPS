import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import { Messages } from '../api/messages.js';
import { Topics } from '../api/topics.js';

import './messages.js';
import './topic-page.html';

Template.topicPage.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('messages');
    Meteor.subscribe('topics');
});

Template.topicPage.helpers({
    topic:()=>{
        var id = FlowRouter.getParam('id');
        return Topics.findOne({_id: id});
    },
    showAddPost() {
        const instance = Template.instance();
        return instance.state.get('showNewMessageForm');
    },
    messages() {
        var r_topic = FlowRouter.getParam('id');
        if (!r_topic)
            return;
        return Messages.find({topic: r_topic});
    },
    isOwner() {
        var r_topic = FlowRouter.getParam('id');
        if (!r_topic)
            return false;
        return Topics.findOne({_id: r_topic}).owner == Meteor.userId();
    },
    topicEditing() {
        return Template.instance().state.get('topicEditing');
    }
})

Template.topicPage.events({
    'submit .send-message'(event) {
        var r_topic = FlowRouter.getParam('id');
        if (!r_topic)
            return;
        // no default submit
        event.preventDefault();
        // get value from element
        const target = event.target;
        const text = target.text.value;
        // insert
        Meteor.call('messages.insert', text, r_topic);
        // clear
        target.text.value='';
        const instance = Template.instance();
        instance.state.set('showNewMessageForm', false);
    },
    'click .respond-b': function(){
        const instance = Template.instance(); 
        instance.state.set('showNewMessageForm', true);
    },
    'click .topic-edit-b': function(){
        const instance = Template.instance();
        instance.state.set('topicEditing', true);
    },
    'click .cancel-b': function(){
        const instance = Template.instance();
        instance.state.set('showNewMessageForm', false);
    },
    'click .cancel-te': function(){
        const instance = Template.instance();
        instance.state.set('topicEditing', false);
    },
    'submit .topic-edit-form'(event){
        var r_topic = FlowRouter.getParam('id');
        if (!r_topic)
            return;
        event.preventDefault();
        const target = event.target;
        let topic = {_id: r_topic, name: target.name.value, text: target.text.value};
        Meteor.call('topics.update', topic);
        Template.instance().state.set('topicEditing', false);
    }
})
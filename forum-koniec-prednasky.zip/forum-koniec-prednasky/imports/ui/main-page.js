import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import { Subforum } from '../api/subforum.js';

import './pms.js';
import './subforum.js';
import './newSubForum.js';
import './online.js';
import './main-page.html';
import { Presences } from '../api/presences.js';

Template.mainPage.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('subforum');
    Meteor.subscribe('presences');
});

Template.mainPage.helpers({
    subforums() {
        return Subforum.find({});
    },
    onlines(){
        return Presences.find({state:"online"});
    }
})

Template.mainPage.events({
    'click .add-subforum': function(){
       FlowRouter.go('/newSubforum/');
    }
})
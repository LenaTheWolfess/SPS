import {Template} from 'meteor/templating';

import "./regUser.html"

Template.regUser.events({
    'click .regUserPM'(){
        FlowRouter.go('/PM/:id', {id: this._id});
    }
})
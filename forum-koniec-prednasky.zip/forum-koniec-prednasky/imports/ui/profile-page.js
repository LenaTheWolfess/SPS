import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import { Profiles } from '../api/profiles.js';

import './profiles.js';
import './profile-page.html';

Template.profilePage.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('profiles');
});

Template.profilePage.helpers({
    profiles(){
        return Profiles.find({userId: Meteor.userId()});
    },
    hasProfile(){
        const instance = Template.instance();
        if (!instance.state.get('hasProfile'))
            instance.state.set('hasProfile', Profiles.findOne({userId: Meteor.userId()}) != null);
        return instance.state.get('hasProfile');
    }
})

Template.profilePage.events({
    'click .createProfile-b': function(){
        const instance = Template.instance();
        var newProfile = {firstName: "", secondName: "", town: "", country: "", age: 0};
        Meteor.call('profiles.insert', newProfile);
    }
})
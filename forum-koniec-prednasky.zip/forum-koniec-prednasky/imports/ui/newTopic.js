import { Meteor } from 'meteor/meteor';
import {Template} from 'meteor/templating';

import './newTopic.html'

Template.newTopic.events({
    'submit .createTopic'(event){
        event.preventDefault();

        const target = event.target;
        const name = target.name.value;
        const text = target.text.value;
        let topic = {name: name, text: text};
        Meteor.call('topics.insert', topic);
        FlowRouter.go('/');
    },
    'click .cancel-b'(){
        FlowRouter.go('/');
    }
});

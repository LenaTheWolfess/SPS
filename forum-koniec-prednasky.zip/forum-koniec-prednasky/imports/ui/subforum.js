import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';

import './subforum-page.js';
import './subforum.html';

Template.registerHelper('formateDate', function(date){
    return date.getDate() + "." + date.getMonth() + "." +date.getFullYear() + " at " + date.getHours() + ":"+date.getMinutes();
});

Template.subforum.events({
    'click .subforumName'(){
        FlowRouter.go('/subforum/:id',{id: this._id});
    }
})
import { Meteor } from 'meteor/meteor';
import {Template} from 'meteor/templating';

import './newSubForum.html'

Template.newSubForum.events({
    'submit .createTopic'(event){
        event.preventDefault();

        const target = event.target;
        const name = target.name.value;
        let sf = {name: name};
        Meteor.call('subforum.create', sf);
        FlowRouter.go('/');
    },
    'click .cancel-b'(){
        FlowRouter.go('/');
    }
});

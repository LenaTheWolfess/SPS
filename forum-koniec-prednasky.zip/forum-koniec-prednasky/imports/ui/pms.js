import {Template} from 'meteor/templating';

import "./pms.html";
import { Pm } from "../api/pm";

Template.pms.onCreated(function(){
    Meteor.subscribe('pm');
    Meteor.subscribe('users');
});

Template.pms.helpers({
    incoming(){
        return Pm.find({}).fetch();
    },
    hasMessage(){
        return Pm.find({}).count() > 0;
    },
    regUsers(){
        return Meteor.users.find({});
    }
});

Template.readPm.onCreated(function(){
    Meteor.subscribe('users');
});
Template.readPm.helpers({
    fromNick(){
        return Meteor.users.findOne({_id: this.from}).username;
    },
    toNick(){
        return Meteor.users.findOne({_id: this.to}).username;
    }
});
Template.readPm.events({
    'click .respond': function(){
        var id = this.from;
        if (this.from == Meteor.userId())
            id = this.to;
        FlowRouter.go('/PM/:id', {id: id});
    },
});
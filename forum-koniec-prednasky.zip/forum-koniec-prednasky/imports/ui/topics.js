import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';

import './topic-page.js';
import './topics.html';

Template.registerHelper('formateDate', function(date){
    return date.getDate() + "." + date.getMonth() + "." +date.getFullYear() + " at " + date.getHours() + ":"+date.getMinutes();
});

Template.topic.events({
    'click .topicName'(){
        FlowRouter.go('/topic/:id',{id: this._id});
    }
})
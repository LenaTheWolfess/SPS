import { Meteor } from 'meteor/meteor';
import {Template} from 'meteor/templating';

import '../api/users.js';
import './regUser.js';

import './pm.html';
Template.pm.onCreated(function(){
    Meteor.subscribe('profiles');
    Meteor.subscribe('users');
});

Template.pm.helpers({
    nick(){
        var id = FlowRouter.getParam('id');
        if(!id) {
            id = Meteor.userId();
        }
        var user = Meteor.users.findOne({_id: id});
        if (user == null)
            return "";
        return user.username;
    },
});

Template.pm.events({
    'submit .pm-form'(event){
        event.preventDefault();

        const target = event.target;

        const text = target.text.value;

        var msg = {from: Meteor.userId(), to: FlowRouter.getParam('id'), text: text};
        Meteor.call('sendPM', msg);
        FlowRouter.go('/myPM');
    },
    'click .cancel-b'(){
        FlowRouter.go('/myPM');
    }
});
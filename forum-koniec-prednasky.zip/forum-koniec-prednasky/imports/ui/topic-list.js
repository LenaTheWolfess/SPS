import {Meteor} from 'meteor/meteor';
import {ReactiveDict} from 'meteor/reactive-dict';
import {Template} from 'meteor/templating';

import { Topics } from '../api/topics.js';

import './newTopic.js';
import './topics.js';
import './topic-list.html';

Template.topicList.onCreated(function () {
    this.state = new ReactiveDict();
    Meteor.subscribe('topics');
});

Template.topicList.helpers({
    topics() {
        return Topics.find({});
    }
})

Template.topicList.events({
    'click .add-topic': function(){
       FlowRouter.go('/newTopic/');
    }
})
import {Meteor} from 'meteor/meteor';
import {Mongo} from 'meteor/mongo';
import {check} from 'meteor/check';

export const Presences = new Mongo.Collection('presences');

if (Meteor.isServer) {
    Meteor.publish('presences', function() {
        return Presences.find({}, {state: 1, userId: 1});
    });
}

Meteor.methods({
    updatePresence: function(state) {

        var connectionId = this.isSimulation ? Meteor.connection._lastSessionId : this.connection.id;

        var update = {};
        update.state = state;
        if (typeof Meteor.userId !== 'undefined' && Meteor.userId())
            update.userId = Meteor.userId();
        
        let prf = Presences.find({userId: update.userId}).fetch();
        for (pr in prf) {
            if (pr._id != connectionId)
                Presences.remove(pr._id);
        }
        Presences.update(connectionId, update);
    }
});
import {Meteor} from 'meteor/meteor';
import {Mongo} from 'meteor/mongo';

export const Subforum = new Mongo.Collection("subforum");

if (Meteor.isServer) {
    Meteor.publish('subforum', function() {
        return Subforum.find();
    });
}

Meteor.methods({
    'subforum.create'(subforum){
        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        // insert
        Subforum.insert({
            name: subforum.name,
            date: new Date(),
            owner: Meteor.userId(),
            username: Meteor.user().username,
        });
    }   
})
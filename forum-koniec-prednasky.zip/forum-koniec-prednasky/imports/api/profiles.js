import {Meteor} from 'meteor/meteor';
import {Mongo} from 'meteor/mongo';
import {check} from 'meteor/check';

export const Profiles = new Mongo.Collection("profiles");

if (Meteor.isServer) {
    Meteor.publish('profiles', function() {
        return Profiles.find();
    });
}

Meteor.methods({
    'profiles.insert'(profile){
        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        let existingProfile = Profiles.findOne({userId: Meteor.userId()});
        if (existingProfile != null){
            console.log('existing profile');
            return;       
        }
        // insert
        Profiles.insert({
           userId: Meteor.userId(),
           firstName: profile.firstName,
           secondName: profile.secondName,
           town: profile.town,
           country: profile.country,
           age: profile.age
        });
    },
    'profiles.update'(profile){
        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        let existingProfile = Profiles.findOne({userId: Meteor.userId()});
        if (existingProfile == null)
            return;
        // update
        Profiles.update(
            {userId: Meteor.userId()},
            {
                $set: {
                    firstName: profile.firstName,
                    secondName: profile.secondName,
                    town: profile.town,
                    country: profile.country,
                    age: profile.age
                }
            }
        );
    }
})
import {Meteor} from 'meteor/meteor';
import {Mongo} from 'meteor/mongo';
import {check} from 'meteor/check';

export const Pm = new Mongo.Collection("pm");

if (Meteor.isServer) {
    Meteor.publish('pm', function pmPublish() {
        if (Meteor.userId()) {
            return Pm.find({$or: [{to: Meteor.userId()},{from: Meteor.userId()}]});
        }
        return;
    });
}

Meteor.methods({
    'sendPM'(msg){
        if(!Meteor.userId())
            throw new Meteor.Error('not-authorized');
        if(Meteor.userId() != msg.from)
            throw new Meteor.Error('not-authorized');
        Pm.insert({
            from: msg.from,
            to: msg.to,
            text: msg.text,
            date: new Date()
        });
    },
});
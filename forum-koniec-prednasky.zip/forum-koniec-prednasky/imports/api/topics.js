import {Meteor} from 'meteor/meteor';
import {Mongo} from 'meteor/mongo';
import {check} from 'meteor/check';

export const Topics = new Mongo.Collection("topics");

if (Meteor.isServer) {
    Meteor.publish('topics', function() {
        return Topics.find();
    });
}

Meteor.methods({
    'topics.insert'(topic){
        check(topic.text, String);
        check(topic.name, String);
        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        // insert
        Topics.insert({
            name: topic.name,
            text: topic.text,
            date: new Date(),
            owner: Meteor.userId(),
            username: Meteor.user().username,
        });
    },
    'topics.remove'(id) {
        check(id, String);
        const topic = Topics.findOne(id);
        if (topic.owner !== Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        Topics.remove(id);
    },
    'topics.update'(topic){
        check(topic._id, String);
        check(topic.name, String);
        check(topic.text, String);
        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        const fTopic = Topics.findOne({_id: topic._id});
        if (fTopic == null)
            return;
        if (fTopic.owner != Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }
        Topics.update(
            {_id: topic._id},
            {
                $set: {
                    name: topic.name,
                    text: topic.text
                }
            }
        );
    }
})